import Foundation

//arrays for questions 1-3
var A: [Int] = [4, 1, 3, 2, 16, 9, 10, 14, 8, 7]
var A2: [Int] = [17, 15, 9, 5, 12, 8, 7, 4, 0, 6, 2, 1]
var A3: [Int] = [19, 18, 11, 5, 12, 8, 7, 4, 0, 6, 2, 1]

//Found code for Heap in swift here: https://medium.com/@puneet.sh25/heap-data-structure-in-swift-4e49e8a9edda
public struct Heap<T> {
    //elements of array and max or min heap priority
    private var elements:[T]!
    private let priority:(T,T) -> Bool

    //gets the size of the array being used
    public var size:Int {
        return elements.count
    }
    //initializes the array
    public init(priority:@escaping (T, T)-> Bool) {
        self.priority = priority
        self.elements = [T]()
    }
    //get the left branch node
    private func leftOf(_ i:Int) -> Int {
        return 2*i + 1
    }
    //gets right branch node
    private func rightOf(_ i:Int) -> Int {
        return leftOf(i) + 1
    }
    //gets parent node
    private func parentOf(_ i:Int) -> Int {
        return (i-1)/2
    }
    
    //shows elements in heap
    private func printArray() {
        print(elements ?? 0)
    }
    
    //MAX-Heapify
    private mutating func heapifyAt(_ i:Int, heapSize:Int) {
        let left = leftOf(i)
        let right = rightOf(i)
        var largest = i
        if left < heapSize && priority(elements[left], elements[largest]){
            largest = left
        }
        if right < heapSize && priority(elements[right],    elements[largest]) {
            largest = right
        }
        if largest != i {
            elements.swapAt(i, largest)
            heapifyAt(largest, heapSize:heapSize)
        }
    }
    
    //Builds Heap
    public mutating func buildHeap(fromArray array:[T]) {
        elements = array
        let midIndex = elements.count/2
        for i in (0...midIndex).reversed() {
            heapifyAt(i, heapSize:elements.count)
        }
    }
    
    //catches errors
    enum HeapError:Error {
        case underflow // throw this error when heap underflows
        case indexNotFound
    }
    //pops from array
    public mutating func pop() throws -> T {
        guard let first = elements.first else {
            throw HeapError.underflow
        }
        if let last = elements.last {
            elements[0] = last
            let heapSize = size - 1
            heapifyAt(0, heapSize: heapSize)
        }
        return first
    }
    private mutating func checkParentAt(_ i:Int) {
        guard i > 0 && i < size else {
            return
        }
        let parent = parentOf(i)
        guard priority(elements[i], elements[parent]) else {
            return
        }
        elements.swapAt(i, parent)
        checkParentAt(parent)
    }
    //inserts an element into the array then moves it to its right spot or a spot that works
    public mutating func insertElement(element:T) {
        elements.append(element)
        checkParentAt(size-1)
    }
    //replaces an index with a new element
    private mutating func replaceElement(_ element:T, atIndex i:Int) throws {
        guard i < size else {
            throw HeapError.indexNotFound
        }
        elements[i] = element
        checkParentAt(i)
    }
}

extension Heap {
    //sorts the array depending on priority
    public static func sort(array:[T], priority: @escaping (T, T) -> Bool) -> [T] {
        var heap:Heap<T> = Heap<T>(priority: priority)
        heap.buildHeap(fromArray: array)
        var heapSize = heap.size
        for i in (0...heapSize-1).reversed() {
            heap.elements.swapAt(0, i)
            heapSize = heapSize-1
            heap.heapifyAt(0, heapSize: heapSize)
        }
        return heap.elements
    }
    
    //extracts the max value from the heap and rearranges the heap, prints the heap and returns the max
    public static func extractMaxHeap(array:[T], priority: @escaping (T, T) -> Bool) throws -> T {
        var maxHeap: Heap<T> = Heap<T>(priority: priority)
        maxHeap.buildHeap(fromArray: array)
        var heapSize = maxHeap.size
        guard heapSize >= 1 else {
            throw HeapError.underflow
        }
        let max = maxHeap.elements[0]
        maxHeap.elements[0] = maxHeap.elements[maxHeap.size-1]
        heapSize = heapSize-1
        maxHeap.heapifyAt(0, heapSize: heapSize)
        maxHeap.elements.removeLast()
        maxHeap.printArray()
        return max
    }
    
    
}
// On playground
A = Heap.sort(array: A, priority: >) // Question #1 Heap sorts the array A
var insertHeap = Heap<Int>(priority: >)
insertHeap.buildHeap(fromArray: A2)
insertHeap.insertElement(element: 11)// Question #2: Inserts 11 into the Max-Heap A2

try Heap.extractMaxHeap(array: A3, priority: >)//Question #3: Extracts the max from the heap
